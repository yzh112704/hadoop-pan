
// 打开分享链接
function openShare(share_md5) {
    window.open("/share/" + share_md5);
}
// 复制接收到的分享链接信息到剪贴板
function copyShare(share_md5, key) {
    var share_text = '链接地址:' + location.host + '/share/' + share_md5 + '口令（区分大小写）:' + key;
    document.getElementById("share").value = share_text;
    var message = document.getElementById("share");
    message.select();
    document.execCommand("copy");
    layer.msg("已复制到剪贴板");
}